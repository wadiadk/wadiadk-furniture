# WADIADK PREMIUM STORE V4

GitHub Pages ready. Upload every file directly to the repository root. No assets folder and no build step.

V4: compact spacing between room categories and Selected Pieces, larger product names/prices/descriptions, stronger Add to Bag buttons. Hero remains unchanged.

GitHub Pages: main / (root).

Product names and prices are demo catalog values until replaced with final commercial catalog.
